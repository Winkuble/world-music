const images = {
    logo: require('~/assets/logo-dark.svg').default,
    noImage: require('~/assets/loading.webp'),
};

export default images;
