import React from 'react'

const Billboard = () => {
  return (
    <div>Billboard</div>
  )
}

export default Billboard