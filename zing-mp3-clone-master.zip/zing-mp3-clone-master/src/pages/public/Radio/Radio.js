import React from 'react'

const Radio = () => {
  return (
    <div>Radio</div>
  )
}

export default Radio