import React from 'react'

const Topic = () => {
  return (
    <div>Topic</div>
  )
}

export default Topic