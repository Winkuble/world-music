import actionTypes from "./actionTypes";

export const setArtist = (artist) => ({
    type: actionTypes.GET_ARTIST,
    artist
})