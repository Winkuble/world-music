import actionTypes from "./actionTypes";

export const setMenuShow = (flag) => ({
    type: actionTypes.SET_MENU_SHOW,
    flag
})